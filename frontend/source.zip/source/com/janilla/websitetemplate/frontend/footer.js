/*
 * MIT License
 *
 * Copyright (c) 2018-2025 Payload CMS, Inc. <info@payloadcms.com>
 * Copyright (c) 2024-2026 Diego Schivo <diego.schivo@janilla.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
import WebComponent from "web-component";

export default class Footer extends WebComponent {

    static get templateNames() {
        return ["footer"];
    }

    static get observedAttributes() {
        return ["data-color-scheme"];
    }

    constructor() {
        super();
    }

    connectedCallback() {
        super.connectedCallback();
        this.addEventListener("change", this.handleChange);
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        this.removeEventListener("change", this.handleChange);
    }

    async updateDisplay() {
        const a = this.closest("app-element");
        this.appendChild(this.interpolateDom({
            $template: "",
            navigation: a.state.footer?.navItems?.length ? {
                $template: "navigation",
                items: a.state.footer.navItems.map(x => ({
                    $template: "list-item",
                    ...x,
                    document: x.type.name === "REFERENCE" ? `${x.document.$type}:${x.document.slug}` : null,
                    href: x.type.name === "CUSTOM" ? x.uri : null,
                    target: x.newTab ? "_blank" : null
                }))
            } : null,
            options: ["auto", "light", "dark"].map(x => ({
                $template: "option",
                value: x,
                text: x.charAt(0).toUpperCase() + x.substring(1),
                selected: x === (this.dataset.colorScheme ?? "auto")
            }))
        }));
    }

    handleChange = event => {
        const el = event.target.closest("select");
        if (el)
            this.closest("app-element").colorScheme = el.value === "auto" ? null : el.value;
    }
}
